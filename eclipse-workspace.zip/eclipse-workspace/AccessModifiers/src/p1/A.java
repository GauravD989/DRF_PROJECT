//Access Modifiers ==21-06-2023=============================
/*
//private
package p1;

public class A {
	
	private static void show()
	{
		System.out.println("Private A Method");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		show();

	}

}*/
/*
//public
package p1;

public class A {
	
	public void show()
	{
		System.out.println("Public A Method");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A obj=new A();
		obj.show();

	}

}*/

//protected
package p1;

public class A {
	
	protected static void show()
	{
		System.out.println("Protected A Method");
	}

	

}
