import java.util.*;
class loops//05-06-2023
{
	public static void main (String args[])
	{
		//while loops
		/*
		int i=1;
		while(i<=5)
		{
			System.out.println("Hello world");
			i++;
		}
		
		int a=1;
		while(i<=5)
		{
			System.out.println(a);
			a++;
		}
		
		int b=5;
		while(b>=1)
		{
			System.out.println(b);
			b--;
		}
		int i=1;
		while(i<=10)
		{
			System.out.println(2*i);
			i++;
		}*/
		/*
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number: ");
		int n=sc.nextInt();
		int i=1;
		while(i<=10)
		{
			System.out.println(n*i);
			i++;
		}*/
		/*
		int i=1;
		int evencount=0;
		while(i<=10)
		{
			if(i%2==0)
			{
				evencount++;
			}
			i++;
		}
		System.out.println("even number "+evencount);*/
		/*
		int i=1;
		int evencount=0;
		while(i<=100)
		{
			if((i%2==0)&&(i%7==0))
			{
				evencount++;
			}
			i++;
		}
		System.out.println("even number in 7 table "+evencount);
		*/
		//for loops
		/*
		for(int i=1;i<=10;i++)
		{
			System.out.println(i);
		}*/
		/*
		for(int i=1;i<=10;i++)
		{
			System.out.println(5*i);
		}*/
		/*
		for(int i=10;i>=1;i--)
		{
			System.out.println(i);
		}
		*/
		
		//do while loops 06-06-2023
		//print 1 output will continu print 0 than loops stop
		/*
		Scanner sc=new Scanner(System.in);
		int num;
		do
		{
			System.out.println("Hello world");
			num=sc.nextInt();
			
			
		}while(num==1);
		*/
		/*
		Scanner sc=new Scanner(System.in);
		
		int num;
		do
		{
			System.out.println("Enter the two number: ");
			int a=sc.nextInt();
			int b=sc.nextInt();
			System.out.println("addition : "+(a+b));
			System.out.println("Press 1:restart and 0:Stop");
			num=sc.nextInt();
		
		}while(num==1);*/
		
		//456 to 654 reverse number
		/*
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number: ");
		int num=sc.nextInt();
		int rev=0;
		while(num>0)
		{
			int rem=num%10;
			rev=rev*10+rem;
			num=num/10;
			
		}
		System.out.println("reverse number: "+rev);
		*/
		//1221 to 1221 palindrome
		/*
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number: ");
		int num=sc.nextInt();
		int onum= num;
		int rev=0;
		while(num>0)
		{
			int rem=num%10;
			rev=rev*10+rem;
			num=num/10;
			
		}
		if(onum==rev)
		{
			System.out.println("It is palindrome: "+rev);
		}
		else
		{
			System.out.println("It is not palindrome: "+rev);
		}
		*/
		
		//patten in java 
		/*
		int n=5;
		for(int i=1;i<=n;i++)//rows change
		{
			for(int j=1;j<=n;j++)//column change
			{
				System.out.print("*");
			}
			System.out.println();
		}*/
		/*
		for(int i=1;i<=4;i++)//rows change
		{
			for(int j=1;j<=i;j++)//column change
			{
				System.out.print("*");
			}
			System.out.println();
		}*/
		/*
		for(int i=4;i>=1;i--)//rows change
		{
			for(int j=1;j<=i;j++)//column change
			{
				System.out.print("*");
			}
			System.out.println();
		}*/
		//08-06-2023
		/*
		int n=5;
		for(int i=1;i<=n;i++)//rows change
		{
			for(int k=1;k<=n-i;k++)
			{
				System.out.print(" ");//space
			}
			for(int j=1;j<=i;j++)//column change
			{
				System.out.print("*");
			}
			System.out.println();
		}*/
		/*
		int n=5;
		for(int i=1;i<=n;i++)//rows change
		{
			for(int k=1;k<=n-i;k++)
			{
				System.out.print(" ");//space
			}
			for(int j=1;j<=i;j++)//column change
			{
				System.out.print("* ");//one space than create piramit
			}
			System.out.println();
		}
		*/
		/*
		int n=5;
		for(int i=1;i<=n;i++)//rows change
		{
			for(int k=1;k<=n-i;k++)
			{
				System.out.print(" ");//space
			}
			for(int j=1;j<=i;j++)//column change
			{
				System.out.print("* ");//one space than create piramit
			}
			System.out.println();
		}
		for(int i=n-1;i>=1;i--)//rows change
		{
			for(int k=1;k<=n-i;k++)
			{
				System.out.print(" ");//space
			}
			for(int j=1;j<=i;j++)//column change
			{
				System.out.print("* ");//one space than create piramit
			}
			System.out.println();
		}*/
		/*
		int n=5;
		for(int i=1;i<=n;i++)//rows change
		{
			for(int j=1;j<=i;j++)//column change
			{
				System.out.print(i);//one space than create piramit
			}
			System.out.println();
		}*/
		/*
		int n=5;
		for(int i=1;i<=n;i++)//rows change
		{
			for(int j=1;j<=i;j++)//column change
			{
				if(i%2==0)//odd and even 
				{
					System.out.print(j);//one space than create piramit
				}
				else
				{
					System.out.print(i);
				}
			}
			System.out.println();
		}*/
		/*
		int n=5;
		for(int i=1;i<=n;i++)//rows change
		{
			for(int j=1;j<=i;j++)//column change
			{
				if((i+j)%2==0)//odd-0 and even-1 
				{
					System.out.print(1);//one space than create piramit
				}
				else
				{
					System.out.print(0);
				}
			}
			System.out.println();
			*/
	
	}
}