//14-06-2023 Methods
import java.util.*;
class methods//14-06-2023
{
	/*
	//methods
	public static void printhello()
	{
		System.out.println("hello");
	}
	//perameters methods
	public static void hello(String name, int age)
	{
		System.out.println("hello "+name+"your age is: "+age);
	}
	//int methods
	public static int add(int a, int b)
	{
		return a+b;
	}*/
	public static void sub(int a, int b)
	{
		System.out.println("subsraction: "+(a-b));
	}
	public static void main (String args[])
	{
		Scanner sc=new Scanner(System.in);
		/*
		printhello();
		hello("abc",19);
		hello("xyz",24);
		int c= add(25,96);
		System.out.println(c);
		
		System.out.println("Enter two numbers");
		int a=sc.nextInt();
		int b=sc.nextInt();
		System.out.println("Addition "+add(25,96));*/
		
		sub(10,5);
		System.out.println("Enter two numbers");
		int a=sc.nextInt();
		int b=sc.nextInt();
		sub(a,b);
		
		
	}
}