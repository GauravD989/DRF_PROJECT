import java.util.Scanner;
class operator
{
	public static void main (String args[])
	{
		/*
		//---------------------31-05-2023----------------------------------
		int a = 20;
		int b = 2;
		//Arithmetic operator--------------------------------------
		System.out.println(a+b);
		System.out.println(a-b);
		System.out.println(a*b);
		System.out.println(a/b);
		System.out.println(a%b);
		
		int c=1;
		System.out.println(c);
		System.out.println(c++);//post increment operator
		System.out.println(++c);//pre increment operator
		System.out.println(c--);//post decrement operator
		System.out.println(--c);//pre decrement operator
		System.out.println(c);
		*/
		
		//comparison operator-------------------------
		/*
		int a = 100;
		System.out.println(a!=10);//true
		System.out.println(a==10);//false
		System.out.println(a<0);//false
		System.out.println(a<=0);//false
		System.out.println(a<=10);//true
		*/
		
		//logical operator-------------------------
		/*
		int a=100;
		int b=10;
		System.out.println(a>10&&a==100);//true
		System.out.println(a>b&&a==b);//false
		System.out.println(a>b||a==b);//true
		System.out.println(!(a>b||a==b));//false
		*/
		
		//ternary operator---------------------------
		/*
		Scanner sc=new Scanner(System.in);
		System.out.println("enter two number: ");
		int a=sc.nextInt();
		int b=sc.nextInt();
		
		int result=(a>b)?a:b;//greater number print ho jaye ga
		System.out.println("Greater number "+result);
		*/
		
		//Assignment operator--------------------------------------
		/*
		Scanner sc=new Scanner(System.in);
		System.out.println("enter two number: ");
		int a=sc.nextInt();
		int b=sc.nextInt();
		
		a%=b;//a=a%b
		System.out.println("Updated value of a  "+a);
		*/
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter two number: ");
		int a=sc.nextInt();
		int b=sc.nextInt();
		
		System.out.println("Addition: "+(a+b));
		System.out.println("Substration: "+(a-b));
		System.out.println("Multiplication: "+(a+b));
		System.out.println("Division: "+(a+b));
		
		
		
		  
		
	}
}