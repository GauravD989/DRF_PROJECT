import java.util.*;
class ifelse
{
	public static void main (String args[])
	{
		//-------------------01-06-2023--------------------------------------
		//Condition Statment-----if------------------------------
		/*
		int a=2;
		if (a==2)
		{
			System.out.println("a is equal to two");
		}
		System.out.println("outside if");
		*/
		
		//if_else-------------------------
		/*
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number: ");
		int n=sc.nextInt();
		
		if(n%2==0)
		{
			System.out.println("It is even number");
		}
		else
		{
			System.out.println("It is odd number");
		}
		*/
		/*
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter two number: ");
		int a=sc.nextInt();
		int b=sc.nextInt();
		
		if(a>b)
		{
			System.out.println(a+" is greater number");
		}
		else
		{
			System.out.println(b+" is greater number");
		}
		*/
		/*
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number: ");
		int n=sc.nextInt();
		
		if(n%7==0)
		{
			System.out.println("It is multiple of 7 number.");
		}
		else
		{
			System.out.println("It not is multiple of 7 number.");
		}
		*/
		//nested if_else-------------------------
		/*
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number: ");
		int n=sc.nextInt();
		
		if(n%7==0)
		{
			System.out.println("It is multiple of 7 number.");
			
			if(n%2==0)
			{
				System.out.println("It is also even number");
			}
			else
			{
				System.out.println("It is odd");
			}
		}
		else
		{
			System.out.println("It not is multiple of 7 number.");
		}
		*/
		/*
		//how to get between three one greater number 
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the three number: ");
		int a=sc.nextInt();
		int b=sc.nextInt();
		int c=sc.nextInt();
		
		if(a>b)
		{
			if(a>c)
			{
				System.out.println(a+" is greater");
			}
			else
			{
				System.out.println(c+" is greater");
			}
		}
		else
		{
			if(b>c)
			{
				System.out.println(b+" is greater");
			}
			else
			{
				System.out.println(c+" is greater");
			}
		}
		*/
		//else if lader-----------------------
		/*
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the (1,2,3) number: ");
		int a=sc.nextInt();
		
		if(a==1)
		{
			System.out.println("Namaste");
		}
		else if(a==2)
		{
			System.out.println("Hello");
		}
		else if(a==3)
		{
			System.out.println("Hii");
		}
		else 
		{
			System.out.println("Invalid number");
		}
		*/
		/*
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the three number: ");
		int a=sc.nextInt();
		int b=sc.nextInt();
		int c=sc.nextInt();
		
		if (a>b&&a>c)
		{
			System.out.println(a+" is greater");
		}
		else if (b>a&&b>c)
		{
			System.out.println(b+" is greater");
		}
		else 
		{
			System.out.println(c+" is greater");
		}
		*/
		//switch conditon--------------------
		/*
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number: ");
		int a=sc.nextInt();
		
		switch(a)
		{
			case 1:
			System.out.println("Marathi");
			break;
			case 2:
			System.out.println("Hindi");
			break;
			case 3:
			System.out.println("English");
			break;
			
			default:
			System.out.println("Invalid");
		}
		*/
		//05-06-2023
		/*
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the two number: ");
		int a=sc.nextInt();
		int b=sc.nextInt();
		System.out.println("1:add 2:sub 3:mul 4:div");
		int c=sc.nextInt();
		
		switch(c)
		{
			case 1:
			System.out.println(a+b);
			break;
			case 2:
			System.out.println(a-b);
			break;
			case 3:
			System.out.println(a*b);
			break;
			case 4:
			System.out.println(a/b);
			break;
			
			default:
			System.out.println("Invalid");
		}*/
		
		//IT IS VOWEL= a,e,i,o,u and other IS CONSONANTS
		/*
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the character: ");
		char ch=sc.next().charAt(0);
		
		switch(ch)
		{
			case 'a':
			case 'e':
			case 'i':
			case 'o':
			case 'u':
			System.out.println("IT IS VOWEL");
			break;
			
			default:
			System.out.println("IT IS CONSONANTS");
			
		}*/
		
	}
}