//14-06-2023 Methods
/*
import java.util.*;
class student
{
	int rollno;
	String name;
	
	public void details()
	{
		System.out.println("********************");
		System.out.println("rollno"+this.rollno);//this is referens
		System.out.println("name"+this.name);
		System.out.println("********************");
		
	}
}
class oopcode//14-06-2023
{
	public static void main (String args[])
	{
		student s1=new student();
		student s2=new student();
		s1.rollno=101;
		s1.name="ABC";
		System.out.println(s1.rollno);
		System.out.println(s1.name);
		s1.details();
		
		s2.rollno=102;
		s2.name="XYZ";
		System.out.println(s2.rollno);
		System.out.println(s2.name);
		s2.details();
		
	}
}*/
/*
import java.util.*;
class rectangle
{
	Scanner sc=new Scanner(System.in);
	int length;
	int breadth;
	public void getdetails()
	{
		System.out.println("Enter value");
		this.length=sc.nextInt();
		this.breadth=sc.nextInt();
		
	}
	
	public void details()
	{
		System.out.println("length "+this.length);//this is referens
		System.out.println("breadth "+this.breadth);
		
	}
}
class oopcode//14-06-2023
{
	public static void main (String args[])
	{
		rectangle s1=new rectangle();
		rectangle s2=new rectangle();
		s1.length=20;
		s1.breadth=10;
		s1.getdetails();
		s1.details();
		
		s2.length=100;
		s2.breadth=50;
		s2.getdetails();
		s2.details();
		
	}
}*/
//16-06-2023 constructors
/*
import java.util.*;
class student
{
	Scanner sc=new Scanner(System.in);
	int rollno;
	String name;
	
	student()
	{
		System.out.println("Object created");
		this.name=sc.nextLine();
		this.rollno=sc.nextInt();
		System.out.println("name: "+this.name+" Id: "+this.rollno);
	}
	
	
}
class oopcode//16-06-2023
{
	public static void main (String args[])
	{
		student s1=new student();
		student s2=new student();
		student s3=new student();
		student s4=new student();
		
		
	}
}*/
//perameters constructors
/*
import java.util.*;
class rectangle
{
	Scanner sc=new Scanner(System.in);
	int length;
	int breadth;
	
	rectangle(int length,int breadth)
	{
		this.length=length;
		this.breadth=breadth;
		System.out.println("Area is perameters "+(this.length*this.breadth));
	}
	
	rectangle()
	{
		System.out.println("Enter value of le");
		this.length=sc.nextInt();
		this.breadth=sc.nextInt();
		System.out.println("Area is non perameters "+(length*breadth));
	}
	
}
class oopcode
{
	public static void main (String args[])
	{
		rectangle r1=new rectangle();
		System.out.println(r1.length);
		rectangle r2=new rectangle(11,14);
		
		
		
	}
}*/
/*
import java.util.*;
class employee
{
	int salary;
	String name;
	
}
class oopcode
{
	public static void main (String args[])
	{
		employee e1=new employee();
		employee e2=new employee();
		
		e1=e2;
		System.out.println(e1);
		System.out.println(e2);
		
	}
}*/
//static methods=19-06-2023==================
/*
import java.util.*;
class employee
{
	int salary;//if you can not give value int = 0
	String name;//if you can not give value String = null
	static String institut="Itvedant";
	
}
class oopcode
{
	public static void main (String args[])
	{
		employee e1=new employee();
		System.out.println(e1.salary);
		System.out.println(e1.name);
		System.out.println(e1.institut);
		
		employee e2=new employee();
		e2.name="Rahul";
		System.out.println(e2.institut);
		System.out.println(e2.name);
		
	}
}*/
//variable argument
/*
import java.util.*;
class oopcode
{
	public static void display(int ... n)
	{
		System.out.println(n);
		for(int x:n)
		{
			System.out.println("Element :"+x);
		}
	}
	public static void main (String args[])
	{
		display(6,58,24,23,53,68,98,75);
		
	}
}*/
//import java.util.*;
/*
class oopcode
{
	public static void main (String args[])
	{
		Object ob1=true;
		Object ob2=47;
		Object ob3="ABC";
		Object ob4=74.98754;
		
		System.out.println(ob1);
		System.out.println(ob2);
		System.out.println(ob3);
		System.out.println(ob4);
		
	}
}*/
//nested class
class outer
{
	class Inner
	{
		public void show()
		{
			System.out.println("Show method in inner class");
		}
	}
}
class oopcode
{
	public static void main (String args[])
	{
		outer ob=new outer();
		outer.Inner ob1=ob.new Inner();
		ob1.show();
	}
}