//08-06-2023 Arrays
import java.util.*;
class code//05-06-2023
{
	public static void main (String args[])
	{
		/*
		int a[]=new int[4];
		
		a[0]=11;
		a[1]=12;
		a[2]=13;
		a[3]=14;
		
		System.out.println(a[0]);
		System.out.println(a[1]);
		System.out.println(a[2]);
		System.out.println(a[3]);*/
		
		/*
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter size of arrays");
		int size=sc.nextInt();
		int a[]=new int[size];//8
		
		System.out.println("Enter array elements ");
		for(int i=0;i<size;i++)
		{
			a[i]=sc.nextInt();
		}
		
		System.out.println("Printing array elements ");
		for(int i=0;i<size;i++)
		{
			System.out.println("Value at "+i+"index is "+a[i]);
		}*/
		/*
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter size of arrays");
		int size=sc.nextInt();
		int a[]=new int[size];
		
		System.out.println("Enter array elements ");
		for(int i=0;i<size;i++)
		{
			a[i]=sc.nextInt();
		}
		
		System.out.println("Enter index ");
		int index=sc.nextInt();
		
		System.out.println("Value at "+index+" is "+a[index]);
		*/
		/*
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter size of arrays");
		int size=sc.nextInt();
		int a[]=new int[size];
		
		System.out.println("Enter array elements ");
		for(int i=0;i<size;i++)
		{
			a[i]=sc.nextInt();
		}
		
		System.out.println("Enter value ");
		int value=sc.nextInt();
		
		for(int i=0;i<size;i++)
		{
			if(value==a[i])
			{
				System.out.println("index= "+i);
			}
		
		}*/
		/*
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter size of arrays");
		int size=sc.nextInt();
		int a[]=new int[size];
		
		System.out.println("Enter array elements ");
		for(int i=0;i<size;i++)
		{
			a[i]=sc.nextInt();
		}
		
		int evenconut=0;
		int oddcout=0;
		
		for(int i=0;i<size;i++)
		{
			if(a[i]%2==0)
			{
				evenconut++;
			}
			else
			{
				oddcout++;
			}
		}
		System.out.println("Even number: "+evenconut);
		System.out.println("Odd number: "+oddcout);
		*/
		/*
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter size of arrays");
		int size=sc.nextInt();
		int a[]=new int[size];
		
		System.out.println("Enter array elements ");
		for(int i=0;i<size;i++)
		{
			a[i]=sc.nextInt();
		}
		
		int min=a[0];
		
		for(int i=0;i<size;i++)
		{
			if(min>a[i])
			{
				min=a[i];
			}
		}
		System.out.println("Smallest : " +min);
		*/
		/*
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter size of arrays");
		int size=sc.nextInt();
		int a[]=new int[size];
		
		System.out.println("Enter array elements ");
		for(int i=0;i<size;i++)
		{
			a[i]=sc.nextInt();
		}
		
		int min=a[0];
		int max=a[0];
		
		for(int i=0;i<size;i++)
		{
			if(min>a[i])
			{
				min=a[i];
			}
			if(max<a[i])
			{
				max=a[i];
			}
		}
		System.out.println("Smallest : " +min);
		System.out.println("Largest : " +max);
		*/
		//tow dimansanal array
		/*
		Scanner sc=new Scanner(System.in);
		int a[][]=new int[2][2];
		
		a[0][0]=21;
		a[0][1]=22;
		a[1][0]=23;
		a[1][1]=24;
		
		System.out.println(a[0][0]);
		System.out.println(a[0][1]);
		System.out.println(a[1][0]);
		System.out.println(a[1][1]);
		*/
		/*
		Scanner sc=new Scanner(System.in);
		int a[][]=new int[2][2];
		
		a[0][0]=21;
		a[0][1]=22;
		a[1][0]=23;
		a[1][1]=24;
		
		for(int i=0;i<2;i++)
		{
			for(int j=0;j<2;j++)
			{
				System.out.println("["+i+"]["+j+"]="+a[i][j]);
				//System.out.println("i+ "+i+"j= "+j);
				//System.out.println(a[i][j]);
			}
		}*/
		/*
		Scanner sc=new Scanner(System.in);
		int a[][]=new int[2][2];
		
		System.out.println("Enter array elements");
		for(int i=0;i<2;i++)
		{
			for(int j=0;j<2;j++)
			{
				System.out.println("["+i+"]["+j+"]");
				a[i][j]=sc.nextInt();
				
			}
		}
		for(int i=0;i<2;i++)
		{
			for(int j=0;j<2;j++)
			{
				System.out.println("["+i+"]["+j+"]="+a[i][j]);
			}
		}*/
		/*
		Scanner sc=new Scanner(System.in);
		int a[][]=new int[2][2];
		
		System.out.println("Enter array elements");
		for(int i=0;i<2;i++)
		{
			for(int j=0;j<2;j++)
			{
				System.out.println("["+i+"]["+j+"]");
				a[i][j]=sc.nextInt();
				
			}
		}
		for(int i=0;i<2;i++)
		{
			for(int j=0;j<2;j++)
			{
				System.out.println(a[i][j]+" ");
			}
			System.out.println();
		}*/
		
	}	
}
