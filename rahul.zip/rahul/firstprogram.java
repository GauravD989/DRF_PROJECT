import java.util.Scanner;
class firstprogram
{
	// static final
	//static final int a = 56;
	
	public static void main(String args[])
	{
		/*
		System.out.println();
		System.out.println("*************************");
		System.out.println();
		System.out.println("    rahul vishwakarma  ");
		System.out.println();
		System.out.println("*************************");
		
		String name="Rahul";
		System.out.println("Welcome "+name);
		*/
		
		//--------------------------30-05-2023----------------------------------
		//-------------------------datatype-------------------------------------
		/*
		int a = 40;
		System.out.println("Value of a is "+a);
		
		byte b = 50;
		System.out.println("Value of b is "+b);
		short c = 4562;
		System.out.println("Value of c is "+c);
		long d = 98726568469l;//while using the long datatype in ,put (l) in end . after the number.
		System.out.println("Value of d is "+d);
		
		float f = 8.254f;//while using the float datatype in ,put (f) in end . after the number.
		System.out.println("Value of f is "+f);
		
		double e = 87.2545422;
		System.out.println("Value of e is "+e);
		
		char ch = 'R';//while useing the char datatype it use single cords.
		System.out.println("Value of ch is "+ch);
		
		boolean bo = true;//retuen true or false
		System.out.println("Value of bo is "+bo);
		
		String name="Rahul";
		System.out.println("Value of name is "+name);
		*/
		//mixing two data types
		/*
		int a=5;
		double b=6.0;
		
		double c=a+b;
		System.out.println("Value of c is "+c);
		*/
		/*
		int a=656;
		System.out.println("Value of a is "+a);*/
		
		//-----Type casting---------
		/*
		double a=55.96;
		int b=(int)a;
		
		System.out.println("b= "+b);*/
		//--------input methods--------------
		/*
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter tow numbers: ");
		int a=sc.nextInt(); 
		int b=sc.nextInt();
		
		System.out.println("Addition is "+(a+b));*/
		
		//---
		System.out.println("Rahul");
		System.out.println("First argument "+args[0]);
		System.out.println("second argument "+args[1]);
		
	}
}