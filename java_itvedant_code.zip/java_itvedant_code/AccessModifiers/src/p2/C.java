package p2;
//protected
import p1.A;//when you import package name . than class name;
public class C extends A{//when you use protected than it use inherited

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		C obj=new C();//using inherited 
		obj.show();

	}

}

