package e;

public class InvalidAgeException extends Exception {

}
