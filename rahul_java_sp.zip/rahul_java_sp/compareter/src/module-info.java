/**
 * 
 */
/**
 * 
 */
module compareter {
}