/**
 * 
 */
/**
 * 
 */
module link_list {
}