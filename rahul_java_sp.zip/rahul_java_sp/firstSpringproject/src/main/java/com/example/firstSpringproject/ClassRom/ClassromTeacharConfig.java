package com.example.firstSpringproject.ClassRom;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan(basePackages = "com.example.firstSpringproject.ClassRom" )
public class ClassromTeacharConfig {

}
