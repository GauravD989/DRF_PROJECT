package com.example.firstSpringproject.component;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan(basePackages = "com.example.firstSpringproject.component")
public class StudentConfig {

}
