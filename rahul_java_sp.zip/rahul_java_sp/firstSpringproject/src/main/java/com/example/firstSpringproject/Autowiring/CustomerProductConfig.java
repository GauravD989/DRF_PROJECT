package com.example.firstSpringproject.Autowiring;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan(basePackages = "com.example.firstSpringproject.Autowiring")//pakage pe right clik and copyqulifing name ko past kar dene ka
public class CustomerProductConfig {

}
